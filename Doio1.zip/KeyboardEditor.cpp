#include "KeyboardEditor.h"
#include "imgui.h"
#include <cstring>
#include <algorithm>
#include <cmath>
#include <windows.h>   // For OPENFILENAME dialog
#include <commdlg.h>
#include <shlwapi.h>

#pragma comment(lib, "comdlg32.lib") // usually already linked via comdlg32
#pragma comment(lib, "shlwapi.lib")

// ─── Layer colours (h,s,v-ish approximations as R,G,B 0-1) ─────────────────
const float KeyboardEditor::kLayerColors[kMaxLayers][3] = {
    {0.25f, 0.55f, 0.95f}, // Layer 0 – blue
    {0.30f, 0.85f, 0.50f}, // Layer 1 – green
    {0.95f, 0.65f, 0.20f}, // Layer 2 – orange
    {0.90f, 0.30f, 0.55f}, // Layer 3 – pink
    {0.65f, 0.40f, 0.95f}, // Layer 4 – purple
    {0.20f, 0.85f, 0.80f}, // Layer 5 – teal
    {0.95f, 0.90f, 0.20f}, // Layer 6 – yellow
    {0.80f, 0.40f, 0.25f}, // Layer 7 – rust
    {0.55f, 0.85f, 0.30f}, // Layer 8 – lime
};

// ─── File dialog helpers ─────────────────────────────────────────────────────

static std::string OpenFileDialog(const char* title, const char* filter) {
    char buf[MAX_PATH] = {};
    OPENFILENAMEA ofn = {};
    ofn.lStructSize  = sizeof(ofn);
    ofn.hwndOwner    = nullptr;
    ofn.lpstrFilter  = filter;
    ofn.lpstrFile    = buf;
    ofn.nMaxFile     = MAX_PATH;
    ofn.lpstrTitle   = title;
    ofn.Flags        = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetOpenFileNameA(&ofn)) return buf;
    return {};
}

static std::string SaveFileDialog(const char* title, const char* filter,
                                  const char* defaultExt) {
    char buf[MAX_PATH] = {};
    OPENFILENAMEA ofn = {};
    ofn.lStructSize   = sizeof(ofn);
    ofn.hwndOwner     = nullptr;
    ofn.lpstrFilter   = filter;
    ofn.lpstrFile     = buf;
    ofn.nMaxFile      = MAX_PATH;
    ofn.lpstrTitle    = title;
    ofn.lpstrDefExt   = defaultExt;
    ofn.Flags         = OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
    if (GetSaveFileNameA(&ofn)) return buf;
    return {};
}

// ─── Constructor ─────────────────────────────────────────────────────────────

KeyboardEditor::KeyboardEditor() {
    m_keycodeDb  = BuildKeycodeDatabase();
    m_keycodeMap = BuildKeycodeMap();
}

// ─── File operations ─────────────────────────────────────────────────────────

void KeyboardEditor::OpenDesign() {
    auto path = OpenFileDialog("Open Design JSON", "JSON Files\0*.json\0All Files\0*.*\0");
    if (path.empty()) return;
    KeyboardLayout tmp;
    if (LoadDesign(path, tmp)) {
        m_layout       = std::move(tmp);
        m_layoutLoaded = true;
        m_selectedKey  = -1;
    }
}

void KeyboardEditor::OpenConfig() {
    auto path = OpenFileDialog("Open Config JSON (me.json)", "JSON Files\0*.json\0All Files\0*.*\0");
    if (path.empty()) return;
    KeyboardConfig tmp;
    if (LoadConfig(path, tmp)) {
        m_config       = std::move(tmp);
        m_configLoaded = true;
        m_configPath   = path;
        m_currentLayer = 0;
        m_selectedKey  = -1;
        m_dirty        = false;
        m_undoStack.clear();
        m_redoStack.clear();
    }
}

void KeyboardEditor::SaveConfig() {
    if (!m_configLoaded) return;
    if (m_configPath.empty()) { SaveConfigAs(); return; }
    if (::SaveConfig(m_configPath, m_config)) m_dirty = false;
}

void KeyboardEditor::SaveConfigAs() {
    if (!m_configLoaded) return;
    auto path = SaveFileDialog("Save Config JSON", "JSON Files\0*.json\0All Files\0*.*\0", "json");
    if (path.empty()) return;
    if (::SaveConfig(path, m_config)) {
        m_configPath = path;
        m_dirty      = false;
    }
}

// ─── Edit operations ─────────────────────────────────────────────────────────

void KeyboardEditor::ApplyKeycode(int keyIdx, const std::string& code) {
    if (!m_configLoaded || !m_layoutLoaded) return;
    if (keyIdx < 0 || keyIdx >= (int)m_layout.keys.size()) return;
    const MatrixPos& mp = m_layout.keys[keyIdx].matrix;
    int fi = m_layout.ConfigIndex(mp);
    if (fi < 0 || fi >= m_config.KeyCount()) return;

    UndoRecord r;
    r.layer   = m_currentLayer;
    r.flatIdx = fi;
    r.oldCode = m_config.Keycode(m_currentLayer, fi);
    r.newCode = code;
    if (r.oldCode == r.newCode) return;

    m_config.Keycode(m_currentLayer, fi) = code;
    PushUndo(r);
    m_dirty = true;
}

void KeyboardEditor::PushUndo(const UndoRecord& r) {
    m_undoStack.push_back(r);
    if (m_undoStack.size() > 200) m_undoStack.pop_front();
    m_redoStack.clear();
}

void KeyboardEditor::Undo() {
    if (m_undoStack.empty()) return;
    auto r = m_undoStack.back(); m_undoStack.pop_back();
    m_config.Keycode(r.layer, r.flatIdx) = r.oldCode;
    m_redoStack.push_back(r);
    m_dirty = true;
}

void KeyboardEditor::Redo() {
    if (m_redoStack.empty()) return;
    auto r = m_redoStack.back(); m_redoStack.pop_back();
    m_config.Keycode(r.layer, r.flatIdx) = r.newCode;
    m_undoStack.push_back(r);
    m_dirty = true;
}

void KeyboardEditor::ResetCurrentLayer() {
    if (!m_configLoaded) return;
    for (auto& kc : m_config.layers[m_currentLayer]) kc = "KC_TRNS";
    m_dirty = true;
    m_redoStack.clear();
}

// ─── Main Render ─────────────────────────────────────────────────────────────

void KeyboardEditor::Render() {
    // ── Keyboard panel (centre/left) ─────────────────────────────────────────
    ImGuiWindowFlags wf = ImGuiWindowFlags_NoCollapse;

    ImGui::SetNextWindowSize(ImVec2(820, 680), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Keyboard View", nullptr, wf)) {
        RenderLayerPanel();
        ImGui::Separator();
        RenderKeyboardPanel();
    }
    ImGui::End();

    // ── Keycode picker (right panel) ─────────────────────────────────────────
    ImGui::SetNextWindowSize(ImVec2(340, 680), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Keycode Picker", nullptr, wf)) {
        RenderKeycodePanel();
    }
    ImGui::End();

    // ── Macro editor ─────────────────────────────────────────────────────────
    ImGui::SetNextWindowSize(ImVec2(480, 300), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Macros", nullptr, wf)) {
        RenderMacroPanel();
    }
    ImGui::End();

    // ── Status bar ───────────────────────────────────────────────────────────
    RenderStatusBar();

    // ── Keyboard shortcuts ───────────────────────────────────────────────────
    ImGuiIO& io = ImGui::GetIO();
    if (io.KeyCtrl) {
        if (ImGui::IsKeyPressed(ImGuiKey_Z)) Undo();
        if (ImGui::IsKeyPressed(ImGuiKey_Y)) Redo();
        if (ImGui::IsKeyPressed(ImGuiKey_S)) SaveConfig();
        if (ImGui::IsKeyPressed(ImGuiKey_O)) OpenConfig();
    }
}

// ─── Layer selector ──────────────────────────────────────────────────────────

void KeyboardEditor::RenderLayerPanel() {
    if (!m_configLoaded) {
        ImGui::TextDisabled("No config loaded");
        return;
    }
    ImGui::Text("Layer:");
    ImGui::SameLine();
    for (int i = 0; i < m_config.LayerCount(); ++i) {
        const float* c = kLayerColors[i % kMaxLayers];
        ImVec4 col(c[0], c[1], c[2], 1.f);
        ImVec4 colDim(c[0]*0.5f, c[1]*0.5f, c[2]*0.5f, 1.f);

        if (m_currentLayer == i) ImGui::PushStyleColor(ImGuiCol_Button, col);
        else                     ImGui::PushStyleColor(ImGuiCol_Button, colDim);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, col);

        char lbl[8]; snprintf(lbl, sizeof(lbl), " %d ", i);
        if (ImGui::Button(lbl)) { m_currentLayer = i; m_selectedKey = -1; }
        ImGui::PopStyleColor(2);
        ImGui::SameLine();
    }
    ImGui::NewLine();
}

// ─── Keyboard visual ─────────────────────────────────────────────────────────

void KeyboardEditor::RenderKeyboardPanel() {
    if (!m_layoutLoaded) {
        ImGui::TextDisabled("Load a design.json to see the keyboard layout.");
        if (ImGui::Button("Open design.json")) OpenDesign();
        return;
    }

    // Compute key unit size to fit the available area
    ImVec2 avail     = ImGui::GetContentRegionAvail();
    float  keyUnit   =  min(avail.x / (m_layout.totalW + 0.5f),
                                avail.y / (m_layout.totalH + 0.5f));
    keyUnit =  max(keyUnit, 20.f);  // minimum 20px per unit
    keyUnit = min(keyUnit, 80.f);  // maximum 80px per unit

    float originX = ImGui::GetCursorScreenPos().x + 12.f;
    float originY = ImGui::GetCursorScreenPos().y + 12.f;

    // Reserve the space so scrolling works if window is tiny
    ImGui::Dummy(ImVec2(m_layout.totalW * keyUnit + 24.f,
                        m_layout.totalH * keyUnit + 24.f));

    DrawKeyboard(originX, originY, keyUnit);
}

void KeyboardEditor::DrawKeyboard(float ox, float oy, float ku) {
    ImDrawList* dl   = ImGui::GetWindowDrawList();
    ImGuiIO&    io   = ImGui::GetIO();
    const float pad  = 3.f;       // inner padding
    const float rounding = 5.f;

    const float* layCol = kLayerColors[m_currentLayer % kMaxLayers];
    ImU32 selColor  = IM_COL32(255, 220, 60, 255);

    for (int ki = 0; ki < (int)m_layout.keys.size(); ++ki) {
        const PhysicalKey& pk = m_layout.keys[ki];

        // Pixel rect of this key
        ImVec2 tl(ox + pk.x * ku + pad, oy + pk.y * ku + pad);
        ImVec2 br(ox + (pk.x + pk.w) * ku - pad, oy + (pk.y + pk.h) * ku - pad);

        // Determine current keycode
        std::string kc = "---";
        if (m_configLoaded) {
            int fi = m_layout.ConfigIndex(pk.matrix);
            kc = m_config.Keycode(m_currentLayer, fi);
        }

        // Key face colour: selected = gold, transparent = dark, else layer colour
        ImU32 faceCol;
        ImU32 borderCol;
        if (ki == m_selectedKey) {
            faceCol  = IM_COL32(220, 180, 20, 255);
            borderCol = IM_COL32(255, 240, 100, 255);
        } else if (kc == "KC_TRNS" || kc == "KC_NO") {
            faceCol  = IM_COL32(40, 42, 48, 200);
            borderCol = IM_COL32(70, 75, 85, 255);
        } else {
            float r = layCol[0], g = layCol[1], b = layCol[2];
            faceCol  = IM_COL32((uint8_t)(r*160), (uint8_t)(g*160), (uint8_t)(b*160), 255);
            borderCol = IM_COL32((uint8_t)(r*220), (uint8_t)(g*220), (uint8_t)(b*220), 255);
        }

        // Draw shadow
        dl->AddRectFilled(
            ImVec2(tl.x+2, tl.y+2), ImVec2(br.x+2, br.y+2),
            IM_COL32(0,0,0,100), rounding);
        // Draw face
        dl->AddRectFilled(tl, br, faceCol, rounding);
        // Draw border
        dl->AddRect(tl, br, borderCol, rounding, 0, 2.f);

        // Matrix position badge (top-left corner, tiny)
        char badge[16];
        snprintf(badge, sizeof(badge), "%d,%d", pk.matrix.row, pk.matrix.col);
        dl->AddText(ImVec2(tl.x + 3, tl.y + 3),
                    IM_COL32(180,180,180,100), badge);

        // Keycode label (centred)
        std::string label = GetKeycodeLabel(kc, m_keycodeMap);
        ImVec2 tsz = ImGui::CalcTextSize(label.c_str());
        float cx = tl.x + (br.x - tl.x - tsz.x) * 0.5f;
        float cy = tl.y + (br.y - tl.y - tsz.y) * 0.5f;
        ImU32 textCol = (ki == m_selectedKey) ? IM_COL32(30,20,0,255) : IM_COL32(230,230,230,255);
        dl->AddText(ImVec2(cx, cy), textCol, label.c_str());

        // Mouse interaction
        ImVec2 mpos = io.MousePos;
        bool hovered = mpos.x >= tl.x && mpos.x < br.x &&
                       mpos.y >= tl.y && mpos.y < br.y;
        if (hovered) {
            // Highlight border
            dl->AddRect(tl, br, IM_COL32(255,255,255,180), rounding, 0, 2.5f);
            // Tooltip: show full keycode
            ImGui::SetTooltip("[%d,%d]  %s", pk.matrix.row, pk.matrix.col, kc.c_str());
            if (ImGui::IsMouseClicked(ImGuiMouseButton_Left))
                m_selectedKey = ki;
        }
    }
}

// ─── Keycode picker ──────────────────────────────────────────────────────────

void KeyboardEditor::RenderKeycodePanel() {
    if (m_selectedKey < 0) {
        ImGui::TextDisabled("Click a key to assign a keycode.");
        return;
    }
    if (!m_configLoaded) {
        ImGui::TextDisabled("No config loaded.");
        return;
    }

    // Show current assignment
    const PhysicalKey& pk = m_layout.keys[m_selectedKey];
    int fi = m_layout.ConfigIndex(pk.matrix);
    const std::string& cur = m_config.Keycode(m_currentLayer, fi);

    ImGui::Text("Selected:  [%d,%d]", pk.matrix.row, pk.matrix.col);
    ImGui::SameLine();
    ImGui::TextColored(ImVec4(1.f,0.9f,0.3f,1.f), "  %s", cur.c_str());

    // Layer copy helper
    ImGui::Separator();
    ImGui::Text("Copy from layer:");
    ImGui::SameLine();
    for (int i = 0; i < m_config.LayerCount(); ++i) {
        if (i == m_currentLayer) { ImGui::SameLine(); continue; }
        char lbl[8]; snprintf(lbl, sizeof(lbl), "%d", i);
        if (ImGui::SmallButton(lbl)) {
            ApplyKeycode(m_selectedKey, m_config.Keycode(i, fi));
        }
        ImGui::SameLine();
    }
    ImGui::NewLine();
    ImGui::Separator();

    // ── Search box ──────────────────────────────────────────────────────────
    ImGui::SetNextItemWidth(-1.f);
    ImGui::InputText("##search", m_searchBuf, sizeof(m_searchBuf));

    // ── Category filter ─────────────────────────────────────────────────────
    {
        const char* all = "All";
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(4,2));
        if (ImGui::RadioButton(all, m_selectedCategory == -1))
            m_selectedCategory = -1;
        for (int ci = 0; ci < (int)KeyCategory::COUNT; ++ci) {
            ImGui::SameLine();
            if (ImGui::RadioButton(CategoryName((KeyCategory)ci), m_selectedCategory == ci))
                m_selectedCategory = ci;
            // wrap every 3
            if ((ci+1) % 4 == 0) ImGui::NewLine();
        }
        ImGui::PopStyleVar();
        ImGui::Separator();
    }

    // ── Keycode list ─────────────────────────────────────────────────────────
    std::string search(m_searchBuf);
    // lowercase for comparison
    std::transform(search.begin(), search.end(), search.begin(), ::tolower);

    ImGui::BeginChild("##kclist", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);

    int col   = 0;
    int ncols = 3;
    float btnW = (ImGui::GetContentRegionAvail().x - (ncols-1)*4) / ncols;

    for (const auto& def : m_keycodeDb) {
        // Category filter
        if (m_selectedCategory >= 0 && (int)def.category != m_selectedCategory) continue;
        // Search filter (matches code or label or tooltip)
        if (!search.empty()) {
            std::string lcode = def.code; std::transform(lcode.begin(), lcode.end(), lcode.begin(), ::tolower);
            std::string llbl  = def.label; std::transform(llbl.begin(), llbl.end(), llbl.begin(), ::tolower);
            std::string ltip  = def.tooltip; std::transform(ltip.begin(), ltip.end(), ltip.begin(), ::tolower);
            if (lcode.find(search) == std::string::npos &&
                llbl.find(search)  == std::string::npos &&
                ltip.find(search)  == std::string::npos) continue;
        }

        // Highlight currently assigned key
        bool isCur = (def.code == cur);
        if (isCur) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f,0.7f,0.1f,1.f));

        if (col > 0 && col < ncols) ImGui::SameLine();

        ImGui::PushID(def.code.c_str());
        if (ImGui::Button(def.label.c_str(), ImVec2(btnW, 0))) {
            ApplyKeycode(m_selectedKey, def.code);
        }
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("%s\n%s", def.code.c_str(), def.tooltip.c_str());
        ImGui::PopID();

        if (isCur) ImGui::PopStyleColor();

        col = (col + 1) % ncols;
    }

    // ── Custom keycode entry ─────────────────────────────────────────────────
    ImGui::Separator();
    ImGui::Text("Custom keycode:");
    static char customBuf[64] = {};
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - 60.f);
    ImGui::InputText("##custom", customBuf, sizeof(customBuf));
    ImGui::SameLine();
    if (ImGui::Button("Apply") && customBuf[0]) {
        ApplyKeycode(m_selectedKey, customBuf);
        customBuf[0] = '\0';
    }

    // ── Layer switching helpers ──────────────────────────────────────────────
    ImGui::Separator();
    ImGui::Text("Layer actions:");
    for (int i = 0; i < m_config.LayerCount(); ++i) {
        char lbl[32];
        snprintf(lbl, sizeof(lbl), "TO(%d)", i);
        ImGui::PushID(lbl);
        if (ImGui::SmallButton(lbl)) ApplyKeycode(m_selectedKey, lbl);
        ImGui::PopID();
        ImGui::SameLine();
        snprintf(lbl, sizeof(lbl), "MO(%d)", i);
        ImGui::PushID(lbl);
        if (ImGui::SmallButton(lbl)) ApplyKeycode(m_selectedKey, lbl);
        ImGui::PopID();
        if ((i+1) % 4 != 0) ImGui::SameLine(); else ImGui::NewLine();
    }

    // ── Macro assignment helpers ─────────────────────────────────────────────
    if (!m_config.macros.empty()) {
        ImGui::NewLine();
        ImGui::Separator();
        ImGui::Text("Macros:");
        for (int mi = 0; mi < (int)m_config.macros.size(); ++mi) {
            char lbl[16]; snprintf(lbl, sizeof(lbl), "M%02d", mi);
            ImGui::PushID(mi + 1000);
            char kclbl[16]; snprintf(kclbl, sizeof(kclbl), "MACRO%02d", mi);
            if (ImGui::SmallButton(lbl)) ApplyKeycode(m_selectedKey, kclbl);
            if (ImGui::IsItemHovered() && !m_config.macros[mi].empty())
                ImGui::SetTooltip("%s", m_config.macros[mi].c_str());
            ImGui::PopID();
            if ((mi+1) % 8 != 0) ImGui::SameLine(); else ImGui::NewLine();
        }
    }

    ImGui::EndChild();
}

// ─── Macro editor ─────────────────────────────────────────────────────────────

void KeyboardEditor::RenderMacroPanel() {
    if (!m_configLoaded || m_config.macros.empty()) {
        ImGui::TextDisabled("No macros in config.");
        return;
    }
    ImGui::Text("%d macros available. Click to edit.", (int)m_config.macros.size());
    ImGui::Separator();
    for (int i = 0; i < (int)m_config.macros.size(); ++i) {
        ImGui::PushID(i);
        char label[16]; snprintf(label, sizeof(label), "MACRO%02d", i);

        bool editing = (m_editingMacro == i);
        if (editing) ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(0.4f,0.6f,0.2f,1.f));
        bool open = ImGui::TreeNodeEx(label, ImGuiTreeNodeFlags_DefaultOpen |
                                             (editing ? ImGuiTreeNodeFlags_Selected : 0));
        if (editing) ImGui::PopStyleColor();

        if (ImGui::IsItemClicked()) m_editingMacro = (m_editingMacro == i) ? -1 : i;

        if (open) {
            // Multiline text editor for macro sequence
            char buf[512];
            strncpy_s(buf, m_config.macros[i].c_str(), sizeof(buf)-1);
            buf[sizeof(buf)-1] = '\0';
            ImGui::SetNextItemWidth(-1.f);
            if (ImGui::InputText("##macroval", buf, sizeof(buf))) {
                m_config.macros[i] = buf;
                m_dirty = true;
            }
            ImGui::TextDisabled("Enter QMK macro string or key sequence");
            ImGui::TreePop();
        }
        ImGui::PopID();
    }
}

// ─── Status bar ───────────────────────────────────────────────────────────────

void KeyboardEditor::RenderStatusBar() {
    ImGuiViewport* vp    = ImGui::GetMainViewport();
    float          h     = ImGui::GetFrameHeight() + 4.f;
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x, vp->Pos.y + vp->Size.y - h));
    ImGui::SetNextWindowSize(ImVec2(vp->Size.x, h));
    ImGui::SetNextWindowViewport(vp->ID);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs |
                             ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                             ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoNav |
                             ImGuiWindowFlags_NoScrollbar;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 2));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.12f, 0.12f, 0.15f, 1.f));
    ImGui::Begin("##statusbar", nullptr, flags);

    // Left side
    if (m_configLoaded) {
        ImGui::Text("Config: %s", m_configPath.empty() ? m_config.name.c_str() : m_configPath.c_str());
        ImGui::SameLine();
        if (m_dirty) ImGui::TextColored(ImVec4(1,0.5f,0.2f,1), " [unsaved]");
    } else {
        ImGui::TextDisabled("No config loaded  |  File → Open Config (me.json)");
    }

    if (m_layoutLoaded) {
        ImGui::SameLine(0, 20);
        ImGui::TextDisabled("Layout: %s  |  %d keys  |  %d layers",
            m_layout.name.c_str(), (int)m_layout.keys.size(), m_config.LayerCount());
    }

    // Right side: shortcuts hint
    ImGui::SameLine(ImGui::GetContentRegionAvail().x - 240.f + ImGui::GetCursorPosX());
    ImGui::TextDisabled("Ctrl+Z Undo  |  Ctrl+Y Redo  |  Ctrl+S Save");

    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar();
}
