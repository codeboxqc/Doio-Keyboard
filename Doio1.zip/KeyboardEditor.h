#pragma once
#include "KeyboardConfig.h"
#include "KeycodeDefs.h"
#include <string>
#include <vector>
#include <deque>
#include <unordered_map>

// ─── Undo / Redo ─────────────────────────────────────────────────────────────

struct UndoRecord {
    int         layer;
    int         flatIdx;
    std::string oldCode;
    std::string newCode;
};

// ─── Main editor ─────────────────────────────────────────────────────────────

class KeyboardEditor {
public:
    KeyboardEditor();

    // File operations (open system file dialog)
    void OpenDesign();
    void OpenConfig();
    void SaveConfig();
    void SaveConfigAs();

    // Edit operations
    bool CanUndo() const { return !m_undoStack.empty(); }
    bool CanRedo() const { return !m_redoStack.empty(); }
    void Undo();
    void Redo();
    void ResetCurrentLayer();

    // Main render call — call once per frame inside ImGui frame
    void Render();

private:
    // ── Data ─────────────────────────────────────────────────────────────────
    KeyboardLayout   m_layout;
    KeyboardConfig   m_config;
    bool             m_layoutLoaded = false;
    bool             m_configLoaded = false;
    std::string      m_configPath;   // last saved/loaded path for quick-save

    int  m_currentLayer  = 0;
    int  m_selectedKey   = -1; // index into m_layout.keys[]
    bool m_dirty         = false;

    // Keycode database
    std::vector<KeycodeDef>                    m_keycodeDb;
    std::unordered_map<std::string, KeycodeDef> m_keycodeMap;

    // Keycode picker state
    char m_searchBuf[128]    = {};
    int  m_selectedCategory  = -1; // -1 = all

    // Undo/redo stacks
    std::deque<UndoRecord> m_undoStack;
    std::deque<UndoRecord> m_redoStack;

    // Macro editor state
    int  m_editingMacro = -1;

    // ── Sub-panels ────────────────────────────────────────────────────────────
    void RenderMenuBar();
    void RenderKeyboardPanel();
    void RenderKeycodePanel();
    void RenderLayerPanel();
    void RenderMacroPanel();
    void RenderStatusBar();

    // ── Keyboard visual ───────────────────────────────────────────────────────
    void DrawKeyboard(float originX, float originY, float keyUnit);

    // ── Helpers ───────────────────────────────────────────────────────────────
    void ApplyKeycode(int keyIdx, const std::string& code);
    void PushUndo(const UndoRecord& r);

    // Layer colors (one per layer, cycling)
    static const int   kMaxLayers = 9;
    static const float kLayerColors[kMaxLayers][3];
};
